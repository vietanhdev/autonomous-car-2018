#include "config.h"

std::shared_ptr<Config> Config::default_instance;
std::string Config::racecar_pkg_name;